/** @type {const} */
const themeColors = {
  primary: { light: '#E10600', dark: '#FF3B30' },
  background: { light: '#F9FAFB', dark: '#121212' },
  surface: { light: '#FFFFFF', dark: '#1D1D1F' },
  foreground: { light: '#121212', dark: '#F9FAFB' },
  muted: { light: '#667085', dark: '#A4ABB7' },
  border: { light: '#E5E7EB', dark: '#343438' },
  success: { light: '#168B5B', dark: '#3CCB8A' },
  warning: { light: '#B7791F', dark: '#E6B54A' },
  error: { light: '#C92A23', dark: '#FF6B63' },
};

module.exports = { themeColors };
