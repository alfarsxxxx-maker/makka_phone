import { useMemo } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { BrandHeader, IconBadge, SectionTitle } from "@/components/makkaphone-ui";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { formatCurrency, walletStatus, walletStatusLabel } from "@/lib/makkaphone-domain";
import { useMakkaphone } from "@/lib/makkaphone-store";

export default function HomeScreen() {
  const router = useRouter();
  const { wallets, products, sales, settings, hydrated } = useMakkaphone();
  const summary = useMemo(() => {
    const today = new Date().toDateString();
    const productsById = new Map(products.map((product) => [product.id, product]));
    const todaySales = sales.filter((sale) => new Date(sale.occurredAt).toDateString() === today);
    const revenue = todaySales.reduce((sum, sale) => sum + sale.quantity * sale.unitPrice, 0);
    const profit = todaySales.reduce((sum, sale) => sum + sale.quantity * (sale.unitPrice - (productsById.get(sale.productId)?.costPrice ?? 0)), 0);
    return {
      walletBalance: wallets.reduce((sum, wallet) => sum + wallet.balance, 0),
      inventoryValue: products.reduce((sum, product) => sum + product.quantity * product.costPrice, 0),
      revenue, profit,
      alerts: [
        ...wallets.filter((wallet) => walletStatus(wallet) !== "healthy").map((wallet) => ({ id: `wallet-${wallet.id}`, title: walletStatusLabel(walletStatus(wallet)), detail: `${wallet.name} — ${formatCurrency(wallet.balance, settings.currency)}`, tone: (walletStatus(wallet) === "critical" || walletStatus(wallet) === "limit" ? "red" : "gold") as "red" | "gold", target: "wallets" })),
        ...products.filter((product) => product.quantity <= product.reorderPoint).map((product) => ({ id: `product-${product.id}`, title: "مخزون يحتاج طلبًا", detail: `${product.name} — متبقي ${product.quantity}`, tone: "gold" as const, target: "inventory" })),
      ],
    };
  }, [products, sales, settings.currency, wallets]);

  return (
    <ScreenContainer className="px-4" containerClassName="bg-[#F9FAFB]">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
        <BrandHeader subtitle={hydrated ? "مركز تشغيل المحل" : "جارٍ تجهيز بيانات المحل"} />

        <View className="bg-[#121212] rounded-[28px] overflow-hidden p-5 mb-5" style={{ direction: "rtl" }}>
          <View className="absolute w-40 h-40 rounded-full bg-[#E10600] -left-12 -top-16 opacity-70" />
          <Text className="text-[#F3B8B5] text-xs font-bold text-right">إجمالي أرصدة المحافظ</Text>
          <Text className="text-white text-3xl font-extrabold text-right mt-2">{formatCurrency(summary.walletBalance, settings.currency)}</Text>
          <View className="flex-row-reverse mt-5 gap-2">
            <View className="flex-1 bg-white/10 rounded-2xl p-3"><Text className="text-white/65 text-[11px] text-right">صافي ربح اليوم</Text><Text className="text-white font-extrabold text-right mt-1">{formatCurrency(summary.profit, settings.currency)}</Text></View>
            <View className="flex-1 bg-white/10 rounded-2xl p-3"><Text className="text-white/65 text-[11px] text-right">قيمة المخزون</Text><Text className="text-white font-extrabold text-right mt-1">{formatCurrency(summary.inventoryValue, settings.currency)}</Text></View>
          </View>
        </View>

        <View className="flex-row-reverse justify-between gap-2 mb-5" style={{ direction: "rtl" }}>
          <QuickAction label="عملية محفظة" icon="arrow.up.arrow.down.circle.fill" onPress={() => router.push("/wallets" as never)} />
          <QuickAction label="جرد بالكاميرا" icon="camera.viewfinder" onPress={() => router.push("/inventory" as never)} />
          <QuickAction label="بحث بالصورة" icon="doc.text.magnifyingglass" onPress={() => router.push("/inventory" as never)} />
          <QuickAction label="التقارير" icon="chart.bar.fill" onPress={() => router.push("/reports" as never)} />
        </View>

        <SectionTitle title="تنبيهات تحتاج متابعة" detail={summary.alerts.length ? `${summary.alerts.length} تنبيه` : "كل شيء مستقر"} onPress={() => router.push("/wallets" as never)} />
        {summary.alerts.length ? summary.alerts.slice(0, 4).map((alert) => <TouchableOpacity key={alert.id} onPress={() => router.push((alert.target === "wallets" ? "/wallets" : "/inventory") as never)} className="bg-surface border border-border rounded-2xl p-4 flex-row-reverse items-center mb-2" activeOpacity={0.75}><IconBadge icon="bell.badge.fill" tone={alert.tone} /><View className="flex-1 mr-3"><Text className="font-extrabold text-foreground text-right" style={{ writingDirection: "rtl" }}>{alert.title}</Text><Text className="text-xs text-muted text-right mt-1" style={{ writingDirection: "rtl" }}>{alert.detail}</Text></View><IconSymbol name="chevron.right" size={22} color="#98A2B3" /></TouchableOpacity>) : <View className="bg-[#E8F7F0] rounded-2xl p-4 flex-row-reverse items-center"><IconBadge icon="lock.shield.fill" tone="green" /><Text className="flex-1 mr-3 text-[#166443] font-bold text-right" style={{ writingDirection: "rtl" }}>لا توجد حدود حرجة أو منتجات وصلت لنقطة إعادة الطلب.</Text></View>}

        <SectionTitle title="نبذة الأداء" />
        <View className="bg-surface border border-border rounded-3xl p-4" style={{ direction: "rtl" }}>
          <MetricRow label="مبيعات اليوم" value={formatCurrency(summary.revenue, settings.currency)} icon="chart.bar.fill" />
          <View className="h-px bg-border my-3" />
          <MetricRow label="محافظ نشطة" value={`${wallets.length} محفظة`} icon="wallet.pass.fill" />
          <View className="h-px bg-border my-3" />
          <MetricRow label="منتجات مسجلة" value={`${products.length} منتج`} icon="shippingbox.fill" />
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function QuickAction({ label, icon, onPress }: { label: string; icon: Parameters<typeof IconSymbol>[0]["name"]; onPress: () => void }) {
  return <TouchableOpacity onPress={onPress} className="flex-1 bg-surface border border-border rounded-2xl py-3 px-1 items-center" activeOpacity={0.75}><IconSymbol name={icon} size={21} color="#E10600" /><Text className="text-[10px] leading-4 text-foreground font-bold text-center mt-1" style={{ writingDirection: "rtl" }}>{label}</Text></TouchableOpacity>;
}
function MetricRow({ label, value, icon }: { label: string; value: string; icon: Parameters<typeof IconSymbol>[0]["name"] }) {
  return <View className="flex-row-reverse items-center"><IconSymbol name={icon} size={20} color="#E10600" /><Text className="flex-1 mr-3 text-sm text-muted text-right" style={{ writingDirection: "rtl" }}>{label}</Text><Text className="text-sm font-extrabold text-foreground">{value}</Text></View>;
}
