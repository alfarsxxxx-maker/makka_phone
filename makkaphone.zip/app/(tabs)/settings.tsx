import { useEffect, useRef, useState } from "react";
import { ActivityIndicator, Alert, Image, Modal, PermissionsAndroid, Platform, ScrollView, Switch, Text, TextInput, TouchableOpacity, View } from "react-native";
import * as Clipboard from "expo-clipboard";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as Notifications from "expo-notifications";
import * as Sharing from "expo-sharing";
import { startReadSMS, stopReadSMS } from "@maniac-tech/react-native-expo-read-sms";
import { ScreenContainer } from "@/components/screen-container";
import { BrandHeader, IconBadge, SectionTitle, Sheet } from "@/components/makkaphone-ui";
import { normalizeArabicDigits, parseWalletSms, type SmsWalletSuggestion, type Wallet } from "@/lib/makkaphone-domain";
import { prepareAlertChannel } from "@/lib/makkaphone-alerts";
import { useMakkaphone } from "@/lib/makkaphone-store";

const mascot = require("@/assets/images/brand/mascot-reference.png");
type RuleDraft = Pick<Wallet, "name" | "senderPatterns" | "smsKeywords" | "balanceAnchors" | "amountAnchors" | "ruleCategory" | "ruleTags">;
type ExportRule = Omit<RuleDraft, "ruleCategory" | "ruleTags"> & { provider?: string; ruleCategory?: string; ruleTags?: string[] };
const toList = (value: string) => value.split(/[,،\n]/).map((item) => item.trim()).filter(Boolean);
const listText = (items: string[]) => items.join(", ");
const newDraft = (): RuleDraft => ({ name: "", senderPatterns: [], smsKeywords: [], balanceAnchors: ["الرصيد", "الرصيد الحالي"], amountAnchors: ["تم شحن", "تم سحب", "تم تحويل"], ruleCategory: "غير مصنف", ruleTags: [] });
const walletToDraft = (wallet: Wallet): RuleDraft => ({ name: wallet.name, senderPatterns: wallet.senderPatterns, smsKeywords: wallet.smsKeywords, balanceAnchors: wallet.balanceAnchors, amountAnchors: wallet.amountAnchors, ruleCategory: wallet.ruleCategory, ruleTags: wallet.ruleTags });

export default function SettingsScreen() {
  const { settings, wallets, updateSettings, updateWallet, addWallet, resetData } = useMakkaphone();
  const [smsText, setSmsText] = useState(""); const [smsResult, setSmsResult] = useState<ReturnType<typeof parseWalletSms> | null>(null);
  const [smsStatus, setSmsStatus] = useState("متوقف");
  const [ruleCenterVisible, setRuleCenterVisible] = useState(false);
  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);
  const [ruleDraft, setRuleDraft] = useState<RuleDraft>(newDraft());
  const [ruleTestText, setRuleTestText] = useState("");
  const [ruleTestResult, setRuleTestResult] = useState<ReturnType<typeof parseWalletSms> | null>(null);
  const [activeCategory, setActiveCategory] = useState("الكل");
  const [activeWalletId, setActiveWalletId] = useState("الكل");
  const [ruleQuery, setRuleQuery] = useState("");
  const [ruleSort, setRuleSort] = useState<"newest" | "oldest" | "name">("newest");
  const [importText, setImportText] = useState("");
  const [backupUri, setBackupUri] = useState<string | null>(null);
  const [fileAction, setFileAction] = useState<"idle" | "exporting" | "sharing" | "reading" | "importing">("idle");
  const [transferNotice, setTransferNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);
  const smsListenerStarted = useRef(false);
  const setRuleField = (field: keyof RuleDraft, value: string) => setRuleDraft((current) => ({ ...current, [field]: field === "name" || field === "ruleCategory" ? value : toList(value) }));

  async function toggleNotifications(value: boolean) { if (value) { await prepareAlertChannel(); const permission = await Notifications.requestPermissionsAsync(); if (!permission.granted) { Alert.alert("التنبيهات غير مفعلة", "يمكن تفعيلها من إعدادات الهاتف لاحقًا."); return; } } updateSettings({ notificationsEnabled: value }); }
  async function toggleSms(value: boolean) {
    if (!value) { stopReadSMS(); smsListenerStarted.current = false; setSmsStatus("متوقف"); updateSettings({ smsImportEnabled: false }); return; }
    if (Platform.OS !== "android") { Alert.alert("ميزة Android فقط", "الالتقاط المباشر لرسائل المحافظ يعمل في ملف APK على Android فقط."); return; }
    try {
      const status = await PermissionsAndroid.requestMultiple([PermissionsAndroid.PERMISSIONS.RECEIVE_SMS, PermissionsAndroid.PERMISSIONS.READ_SMS]);
      const granted = status[PermissionsAndroid.PERMISSIONS.RECEIVE_SMS] === PermissionsAndroid.RESULTS.GRANTED && status[PermissionsAndroid.PERMISSIONS.READ_SMS] === PermissionsAndroid.RESULTS.GRANTED;
      if (!granted) { Alert.alert("لم تُمنح الصلاحية", "يمكنك متابعة استيراد رسالة يدويًا دون وصول شامل إلى الرسائل."); setSmsStatus("لم تُمنح الصلاحية"); return; }
      updateSettings({ smsImportEnabled: true }); setSmsStatus("جارٍ تشغيل الالتقاط…");
    } catch { setSmsStatus("تعذر طلب الصلاحية"); }
  }
  useEffect(() => {
    if (!settings.smsImportEnabled || Platform.OS !== "android" || smsListenerStarted.current) return;
    let active = true;
    try {
      startReadSMS((status, sms, error) => {
        if (!active) return;
        if (status !== "success") { setSmsStatus(error || "تعذر بدء الاستماع"); return; }
        const content = Array.isArray(sms) ? sms.map(String).join(" ") : String(sms ?? "");
        const suggestion = parseWalletSms(content, wallets);
        setSmsText(content); setSmsResult(suggestion);
        setSmsStatus(suggestion.confidence === "low" ? "تمت قراءة رسالة غير مؤكدة" : "تم استخراج اقتراح من رسالة واردة");
      }).then(() => { if (active) { smsListenerStarted.current = true; setSmsStatus("في انتظار رسائل المحافظ"); } }).catch(() => { if (active) setSmsStatus("يتطلب هذا البناء APK مخصصًا، وليس Expo Go"); });
    } catch { setSmsStatus("يتطلب هذا البناء APK مخصصًا، وليس Expo Go"); }
    return () => { active = false; };
  }, [settings.smsImportEnabled, wallets]);
  function approveSmsBalance() {
    if (!smsResult?.provider || smsResult.balance === undefined) return;
    const wallet = wallets.find((item) => item.name.toLowerCase().includes(smsResult.provider!.toLowerCase()) || smsResult.provider!.toLowerCase().includes(item.name.toLowerCase()));
    if (!wallet) { Alert.alert("محفظة غير مسجلة", `سجل ${smsResult.provider} أولًا ثم أعد اعتماد الرصيد.`); return; }
    updateWallet(wallet.id, { balance: smsResult.balance, updateSource: "sms" });
    setSmsStatus(`تم اعتماد رصيد ${wallet.name} بعد مراجعتك.`);
  }
  const ruleCategories = ["الكل", ...Array.from(new Set(wallets.map((wallet) => wallet.ruleCategory || "غير مصنف")))];
  const filteredRules = wallets.filter((wallet) => {
    const query = ruleQuery.trim().toLowerCase();
    const categoryMatch = activeCategory === "الكل" || wallet.ruleCategory === activeCategory;
    const walletMatch = activeWalletId === "الكل" || wallet.id === activeWalletId;
    const searchText = [wallet.name, wallet.provider, wallet.ruleCategory, ...wallet.ruleTags, ...wallet.senderPatterns, ...wallet.smsKeywords].join(" ").toLowerCase();
    return categoryMatch && walletMatch && (!query || searchText.includes(query));
  }).sort((left, right) => {
    if (ruleSort === "name") return left.name.localeCompare(right.name, "ar");
    const leftTime = new Date(left.createdAt).getTime(); const rightTime = new Date(right.createdAt).getTime();
    return ruleSort === "newest" ? rightTime - leftTime : leftTime - rightTime;
  });
  function openNewRule() { setEditingRuleId(null); setRuleDraft(newDraft()); setRuleTestText(""); setRuleTestResult(null); }
  function editRule(wallet: Wallet) { setEditingRuleId(wallet.id); setRuleDraft(walletToDraft(wallet)); setRuleTestText(""); setRuleTestResult(null); }
  function duplicateRule(wallet: Wallet) { setEditingRuleId(null); setRuleDraft({ ...walletToDraft(wallet), name: `نسخة من ${wallet.name}`, ruleTags: Array.from(new Set([...wallet.ruleTags, "مكررة"])) }); setRuleTestText(""); setRuleTestResult(null); setTransferNotice({ tone: "success", text: "تم فتح نسخة مكررة في شاشة التعديل. الصق رسالة ثم استخدم زر تشغيل الاختبار قبل حفظها." }); }
  function openRule(wallet: Wallet) { Alert.alert("إدارة القاعدة", wallet.name, [{ text: "تكرار وفتح الاختبار", onPress: () => duplicateRule(wallet) }, { text: "تعديل", onPress: () => editRule(wallet) }, { text: "إلغاء", style: "cancel" }]); }
  function testDraftRule() {
    if (!ruleTestText.trim()) { Alert.alert("رسالة الاختبار مطلوبة", "الصق رسالة نصية للتأكد من النتيجة قبل حفظ القاعدة."); return; }
    const candidate = { name: ruleDraft.name.trim() || "القاعدة قيد الاختبار", senderPatterns: ruleDraft.senderPatterns, smsKeywords: ruleDraft.smsKeywords, balanceAnchors: ruleDraft.balanceAnchors, amountAnchors: ruleDraft.amountAnchors };
    setRuleTestResult(parseWalletSms(ruleTestText, [candidate]));
  }
  function saveRule() {
    if (!ruleDraft.name.trim()) { Alert.alert("اسم القاعدة مطلوب", "أدخل اسم المحفظة أو القاعدة أولًا."); return; }
    if (editingRuleId) updateWallet(editingRuleId, ruleDraft);
    else addWallet({ name: ruleDraft.name.trim(), provider: ruleDraft.name.trim(), accountIdentifier: "", senderPatterns: ruleDraft.senderPatterns, smsKeywords: ruleDraft.smsKeywords, balanceAnchors: ruleDraft.balanceAnchors, amountAnchors: ruleDraft.amountAnchors, ruleCategory: ruleDraft.ruleCategory.trim() || "غير مصنف", ruleTags: ruleDraft.ruleTags, balance: 0, maximumBalance: 0, singleTransactionLimit: 0, warningThreshold: 0, criticalThreshold: 0, dailyLimit: 0, monthlyLimit: 0 });
    setEditingRuleId(null); setRuleDraft(newDraft()); Alert.alert("تم الحفظ", "حُفظت القاعدة محليًا على هذا الجهاز.");
  }
  function buildExportData() {
    return { format: "makkaphone-sms-rules", version: 2, exportedAt: new Date().toISOString(), rules: wallets.map((wallet) => ({ provider: wallet.provider, ...walletToDraft(wallet) })) };
  }
  async function exportRules() {
    const content = JSON.stringify(buildExportData(), null, 2);
    await Clipboard.setStringAsync(content);
    Alert.alert("تم النسخ", "تم نسخ قواعد الرسائل بصيغة JSON إلى الحافظة.");
  }
  async function exportRulesFile() {
    const content = JSON.stringify(buildExportData(), null, 2);
    try {
      setFileAction("exporting"); setTransferNotice(null);
      if (Platform.OS === "web") { await Clipboard.setStringAsync(content); setTransferNotice({ tone: "success", text: "تم نسخ JSON إلى الحافظة. المشاركة المباشرة للملف متاحة في APK على Android." }); return; }
      const filename = `makkaphone-sms-rules-${new Date().toISOString().slice(0, 10)}.json`;
      const uri = `${FileSystem.cacheDirectory}${filename}`;
      await FileSystem.writeAsStringAsync(uri, content, { encoding: FileSystem.EncodingType.UTF8 });
      updateSettings({ lastRulesBackupAt: new Date().toISOString(), lastRulesBackupFilename: filename });
      setBackupUri(uri);
      if (!(await Sharing.isAvailableAsync())) { await Clipboard.setStringAsync(content); setTransferNotice({ tone: "success", text: "تم إنشاء النسخة ونسخ JSON إلى الحافظة لأن المشاركة غير متاحة." }); return; }
      setFileAction("sharing");
      await Sharing.shareAsync(uri, { dialogTitle: "تصدير قواعد رسائل مكة فون", mimeType: "application/json" });
      setTransferNotice({ tone: "success", text: "تم إنشاء ملف JSON وفتح خيارات مشاركته." });
    } catch { setTransferNotice({ tone: "error", text: "تعذر تصدير الملف. استخدم نسخ JSON كبديل." }); }
    finally { setFileAction("idle"); }
  }
  async function shareLatestBackup() {
    if (!backupUri) { setTransferNotice({ tone: "error", text: "أنشئ ملف JSON أولًا ثم شاركه." }); return; }
    try { setFileAction("sharing"); setTransferNotice(null); if (!(await Sharing.isAvailableAsync())) throw new Error("غير متاح"); await Sharing.shareAsync(backupUri, { dialogTitle: "مشاركة ملف قواعد مكة فون", mimeType: "application/json" }); setTransferNotice({ tone: "success", text: "تم فتح تطبيقات المراسلة والبريد لمشاركة ملف النسخة الاحتياطية." }); } catch { setTransferNotice({ tone: "error", text: "تعذر فتح المشاركة لهذا الملف. أنشئ نسخة جديدة ثم أعد المحاولة." }); } finally { setFileAction("idle"); }
  }
  async function importRulesFile() {
    try {
      setFileAction("reading"); setTransferNotice(null);
      const result = await DocumentPicker.getDocumentAsync({ type: ["application/json", "text/json", "text/plain"], copyToCacheDirectory: true });
      if (result.canceled) { setTransferNotice({ tone: "error", text: "تم إلغاء اختيار ملف JSON." }); return; }
      const asset = result.assets[0];
      const webFile = (asset as typeof asset & { file?: { text: () => Promise<string> } }).file;
      const content = Platform.OS === "web" && webFile ? await webFile.text() : await FileSystem.readAsStringAsync(asset.uri, { encoding: FileSystem.EncodingType.UTF8 });
      setImportText(content); setTransferNotice({ tone: "success", text: `تمت قراءة ${asset.name}. راجع النص ثم اضغط تطبيق القواعد.` });
    } catch { setTransferNotice({ tone: "error", text: "تعذر فتح ملف JSON. تحقق من صيغة الملف ثم أعد المحاولة." }); }
    finally { setFileAction("idle"); }
  }
  async function pasteRules() {
    try { const value = await Clipboard.getStringAsync(); if (!value.trim()) { Alert.alert("الحافظة فارغة", "انسخ ملف القواعد النصي أولًا."); return; } setImportText(value); } catch { Alert.alert("تعذر اللصق", "الصق النص يدويًا في الحقل أدناه."); }
  }
  function previewImportRules() {
    try {
      const parsed = JSON.parse(importText) as { rules?: ExportRule[] } | ExportRule[];
      const rules = Array.isArray(parsed) ? parsed : parsed.rules;
      if (!Array.isArray(rules) || !rules.length) throw new Error("لا توجد قواعد");
      const valid = rules.filter((rule) => Boolean(rule?.name && Array.isArray(rule.senderPatterns) && Array.isArray(rule.smsKeywords) && Array.isArray(rule.balanceAnchors) && Array.isArray(rule.amountAnchors)));
      if (!valid.length) throw new Error("بنية غير صالحة");
      const updates = valid.filter((rule) => wallets.some((wallet) => wallet.name.trim().toLowerCase() === rule.name.trim().toLowerCase() || wallet.provider.trim().toLowerCase() === String(rule.provider ?? rule.name).trim().toLowerCase())).length;
      Alert.alert("اختر طريقة استيراد القواعد", `يتضمن الملف ${valid.length} قاعدة. يوجد ${updates} قاعدة مطابقة حاليًا. لن تُحذف أي قاعدة من الجهاز.`, [{ text: "إلغاء", style: "cancel" }, { text: "إضافة الجديد فقط", onPress: () => applyImportRules("newOnly") }, { text: "دمج آمن وتحديث المطابق", onPress: () => applyImportRules("merge") }]);
    } catch { setTransferNotice({ tone: "error", text: "ملف قواعد غير صالح. تأكد من أن النص صادر من مكة فون ثم أعد المحاولة." }); }
  }
  const importRules = previewImportRules;
  function applyImportRules(mode: "merge" | "newOnly") {
    try {
      setFileAction("importing"); setTransferNotice(null);
      const parsed = JSON.parse(importText) as { rules?: ExportRule[] } | ExportRule[];
      const rules = Array.isArray(parsed) ? parsed : parsed.rules;
      if (!Array.isArray(rules) || !rules.length) throw new Error("لا توجد قواعد");
      let applied = 0; let updated = 0; let skipped = 0;
      rules.forEach((rule) => {
        if (!rule?.name || !Array.isArray(rule.senderPatterns) || !Array.isArray(rule.smsKeywords) || !Array.isArray(rule.balanceAnchors) || !Array.isArray(rule.amountAnchors)) return;
        const existing = wallets.find((wallet) => wallet.name.trim().toLowerCase() === rule.name.trim().toLowerCase() || wallet.provider.trim().toLowerCase() === String(rule.provider ?? rule.name).trim().toLowerCase());
        const importedTags = Array.isArray(rule.ruleTags) ? rule.ruleTags : [];
        const data = { name: rule.name.trim(), senderPatterns: rule.senderPatterns, smsKeywords: rule.smsKeywords, balanceAnchors: rule.balanceAnchors, amountAnchors: rule.amountAnchors, ruleCategory: rule.ruleCategory?.trim() || "غير مصنف", ruleTags: Array.from(new Set([...(existing?.ruleTags ?? []), ...importedTags, "مستوردة حديثًا"])) };
        if (existing && mode === "merge") { updateWallet(existing.id, data); updated += 1; }
        else if (!existing) addWallet({ ...data, provider: String(rule.provider ?? rule.name).trim(), accountIdentifier: "", balance: 0, maximumBalance: 0, singleTransactionLimit: 0, warningThreshold: 0, criticalThreshold: 0, dailyLimit: 0, monthlyLimit: 0 });
        else { skipped += 1; return; }
        applied += 1;
      });
      if (!applied && !skipped) throw new Error("بنية غير صالحة");
      setImportText(""); setTransferNotice({ tone: "success", text: applied ? `تم تطبيق ${applied} قاعدة: ${updated} محدّثة و${applied - updated} مضافة${skipped ? `، وتُركت ${skipped} قاعدة مطابقة دون تغيير` : ""}.` : `لم تُضف أي قاعدة جديدة؛ توجد ${skipped} قاعدة مطابقة محفوظة دون تغيير.` });
    } catch { setTransferNotice({ tone: "error", text: "ملف قواعد غير صالح. تأكد من أن النص صادر من مكة فون ثم أعد المحاولة." }); }
    finally { setFileAction("idle"); }
  }
  return <ScreenContainer className="px-4" containerClassName="bg-[#F9FAFB]"><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}><BrandHeader subtitle="ضبط التطبيق والخصوصية" />
    <View className="bg-[#7E120D] rounded-3xl overflow-hidden p-4 mb-5 flex-row-reverse items-center"><Image source={mascot} className="w-20 h-20 rounded-2xl" resizeMode="cover" /><View className="flex-1 mr-3"><Text className="text-white font-extrabold text-right">{settings.shopName}</Text><Text className="text-white/75 text-xs leading-5 text-right mt-1">هوية مكة فون مخصصة لخدمات المحمول والدفع الإلكتروني.</Text></View></View>
    <SectionTitle title="إعدادات المتجر" /><SettingInput label="اسم المتجر" value={settings.shopName} onChangeText={(shopName) => updateSettings({ shopName })} /><View className="flex-row-reverse gap-3"><View className="flex-1"><SettingInput label="العملة" value={settings.currency} onChangeText={(currency) => updateSettings({ currency })} /></View><View className="flex-1"><SettingInput label="أدنى هامش ربح %" value={String(settings.minimumMargin)} onChangeText={(minimumMargin) => updateSettings({ minimumMargin: Number(minimumMargin) || 0 })} keyboardType="decimal-pad" /></View></View>
    <SectionTitle title="التنبيهات والخصوصية" /><SettingsRow icon="bell.badge.fill" title="تنبيهات الحدود والمخزون" description="تنبيه محلي عند انخفاض رصيد محفظة أو مخزون منتج." control={<Switch value={settings.notificationsEnabled} onValueChange={toggleNotifications} trackColor={{ false: "#D0D5DD", true: "#F3B8B5" }} thumbColor={settings.notificationsEnabled ? "#E10600" : "#FFFFFF"} />} /><SettingsRow icon="lock.shield.fill" title="استخراج رصيد المحافظ من SMS" description="اختياري. يحلل الرسائل محليًا ويعرض اقتراحًا يحتاج اعتمادك. يعمل داخل APK مخصص على Android؛ وقد يتطلب النشر العام مراجعة أهلية سياسة متجر التطبيقات." control={<Switch value={settings.smsImportEnabled} onValueChange={toggleSms} trackColor={{ false: "#D0D5DD", true: "#F3B8B5" }} thumbColor={settings.smsImportEnabled ? "#E10600" : "#FFFFFF"} />} />
    <SectionTitle title="ترتيب قواعد الرسائل" /><View className="bg-surface border border-border rounded-3xl p-4 mb-5"><Text className="text-xs text-muted text-right">اختر ترتيب القواعد داخل مركز الرسائل.</Text><View className="flex-row-reverse flex-wrap gap-2 mt-3">{([{ value: "newest", label: "الأحدث إضافة" }, { value: "oldest", label: "الأقدم إضافة" }, { value: "name", label: "اسم المحفظة" }] as const).map((item) => <TouchableOpacity key={item.value} onPress={() => setRuleSort(item.value)} className={`rounded-full px-3 py-2 ${ruleSort === item.value ? "bg-primary" : "bg-[#F2F4F7]"}`}><Text className={`text-xs font-bold ${ruleSort === item.value ? "text-white" : "text-muted"}`}>{item.label}</Text></TouchableOpacity>)}</View></View>
    <SectionTitle title="مركز قواعد الرسائل" /><TouchableOpacity onPress={() => setRuleCenterVisible(true)} className="bg-surface border border-border rounded-3xl p-4 flex-row-reverse items-center"><IconBadge icon="doc.text.magnifyingglass" tone="red" /><View className="flex-1 mr-3"><Text className="font-extrabold text-foreground text-right">إضافة وتحديث قواعد SMS</Text><Text className="text-[11px] leading-4 text-muted text-right mt-1">عدّل المرسلين والكلمات وعبارات الرصيد. القواعد الحالية ابتدائية؛ فودافون كاش واتصالات كاش يحتاجان مراجعة برسائل حقيقية قبل الاعتماد.</Text></View><Text className="text-primary text-lg">‹</Text></TouchableOpacity>
    <SectionTitle title="رسائل المحافظ" /><View className="bg-surface border border-border rounded-3xl p-4"><View className="flex-row-reverse items-center justify-between"><Text className="text-xs text-muted text-right">حالة الالتقاط</Text><Text className={`text-xs font-bold ${settings.smsImportEnabled ? "text-success" : "text-muted"}`}>{smsStatus}</Text></View><Text className="text-xs text-muted leading-5 text-right mt-3">الصق نموذج رسالة أو راقب نتيجة رسالة واردة. تعتمد المطابقة على القواعد المخزنة محليًا، ولا تعتمد أي رصيد دون مراجعتك.</Text><TextInput multiline value={smsText} onChangeText={setSmsText} placeholder="مثال: تم شحن محفظتك... الرصيد الحالي ..." placeholderTextColor="#98A2B3" className="bg-[#F7F8FA] border border-border rounded-xl px-3 py-3 text-right text-foreground mt-3 min-h-24" style={{ writingDirection: "rtl", textAlignVertical: "top" }} /><TouchableOpacity onPress={() => setSmsResult(parseWalletSms(smsText, wallets))} className="bg-primary rounded-xl p-3 mt-3"><Text className="text-white font-extrabold text-center">تحليل الرسالة</Text></TouchableOpacity>{smsResult ? <View className="bg-[#F7F8FA] rounded-xl mt-3 p-3"><Text className="font-extrabold text-foreground text-right">النتيجة المقترحة</Text><Text className="text-xs text-muted text-right mt-1">المزود: {smsResult.provider ?? "غير معروف"} · الرصيد: {smsResult.balance ?? "غير مستخرج"}</Text><Text className="text-xs text-muted text-right mt-1">الثقة: {smsResult.confidence === "high" ? "مرتفعة" : smsResult.confidence === "medium" ? "متوسطة" : "منخفضة"}</Text>{smsResult.provider && smsResult.balance !== undefined ? <TouchableOpacity onPress={approveSmsBalance} className="bg-[#E8F7F0] rounded-xl p-3 mt-3"><Text className="text-success font-extrabold text-center">اعتماد الرصيد بعد المراجعة</Text></TouchableOpacity> : null}</View> : null}</View>
    <SectionTitle title="إدارة البيانات" /><TouchableOpacity onPress={() => Alert.alert("مسح بيانات التشغيل", "سيحذف المحافظ والمنتجات والعمليات المخزنة على هذا الجهاز فقط. لا يشمل نص قواعد تم نسخه خارج التطبيق.", [{ text: "إلغاء", style: "cancel" }, { text: "مسح البيانات", style: "destructive", onPress: resetData }])} className="bg-[#FFF0EE] rounded-2xl p-4 flex-row-reverse items-center"><IconBadge icon="arrow.triangle.2.circlepath" tone="red" /><View className="flex-1 mr-3"><Text className="font-extrabold text-error text-right">إعادة ضبط بيانات هذا الجهاز</Text><Text className="text-xs text-[#B42318] text-right mt-1">لا يشمل ذلك أي ملف قواعد تم تصديره يدويًا.</Text></View></TouchableOpacity>
  </ScrollView>
  <Modal visible={ruleCenterVisible} transparent animationType="slide" onRequestClose={() => setRuleCenterVisible(false)}><View className="flex-1 bg-black/45 justify-end"><Sheet><View className="flex-row-reverse justify-between items-center mb-4"><Text className="text-lg font-extrabold text-foreground">مركز قواعد SMS</Text><TouchableOpacity onPress={() => setRuleCenterVisible(false)} className="w-9 h-9 rounded-full bg-[#F2F4F7] items-center justify-center"><Text className="text-xl text-muted">×</Text></TouchableOpacity></View><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 12 }}><Text className="text-xs text-muted leading-5 text-right">أضف القاعدة أو عدّلها بعد مقارنة رسالة حقيقية من المزود، ثم اختبرها هنا قبل الحفظ. لا يرسل التطبيق نص الرسائل خارج الجهاز.</Text><View className="flex-row-reverse flex-wrap gap-2 mt-3"><TouchableOpacity disabled={fileAction !== "idle"} onPress={exportRulesFile} className={`rounded-xl px-3 py-3 ${fileAction === "exporting" || fileAction === "sharing" ? "bg-[#C9A39F]" : "bg-primary"}`}>{fileAction === "exporting" || fileAction === "sharing" ? <ActivityIndicator color="#FFFFFF" /> : <Text className="text-white font-extrabold text-center text-xs">تصدير ومشاركة JSON</Text>}</TouchableOpacity><TouchableOpacity disabled={fileAction !== "idle"} onPress={importRulesFile} className="bg-[#F2F4F7] rounded-xl px-3 py-3">{fileAction === "reading" ? <ActivityIndicator color="#344054" /> : <Text className="text-foreground font-extrabold text-center text-xs">استيراد ملف</Text>}</TouchableOpacity>{backupUri ? <TouchableOpacity disabled={fileAction !== "idle"} onPress={shareLatestBackup} className="bg-[#1B2735] rounded-xl px-3 py-3">{fileAction === "sharing" ? <ActivityIndicator color="#FFFFFF" /> : <Text className="text-white font-extrabold text-center text-xs">مشاركة آخر ملف</Text>}</TouchableOpacity> : null}<TouchableOpacity onPress={exportRules} className="bg-[#FCE8E7] rounded-xl px-3 py-3"><Text className="text-primary font-extrabold text-center text-xs">نسخ JSON</Text></TouchableOpacity><TouchableOpacity onPress={pasteRules} className="bg-[#F2F4F7] rounded-xl px-3 py-3"><Text className="text-foreground font-extrabold text-center text-xs">لصق JSON</Text></TouchableOpacity></View>{transferNotice ? <View className={`rounded-xl p-3 mt-3 ${transferNotice.tone === "success" ? "bg-[#E8F7F0]" : "bg-[#FFF0EE]"}`}><Text className={`text-xs font-bold text-right ${transferNotice.tone === "success" ? "text-success" : "text-error"}`}>{transferNotice.text}</Text></View> : null}<View className="bg-[#F7F8FA] rounded-xl p-3 mt-3"><Text className="text-[11px] text-muted text-right">آخر ملف احتياطي تم إنشاؤه</Text><Text className="text-xs font-extrabold text-foreground text-right mt-1">{settings.lastRulesBackupAt ? `${formatBackupTime(settings.lastRulesBackupAt)}${settings.lastRulesBackupFilename ? ` · ${settings.lastRulesBackupFilename}` : ""}` : "لم يتم إنشاء ملف احتياطي بعد"}</Text></View><TextInput multiline value={importText} onChangeText={setImportText} placeholder="الصق أو حمّل ملف JSON هنا للاستيراد" placeholderTextColor="#98A2B3" className="bg-[#F7F8FA] border border-border rounded-xl px-3 py-3 text-right text-foreground mt-3 min-h-20" style={{ writingDirection: "rtl", textAlignVertical: "top" }} />{importText ? <TouchableOpacity disabled={fileAction !== "idle"} onPress={importRules} className={`rounded-xl py-3 mt-2 ${fileAction === "importing" ? "bg-[#9AD7B8]" : "bg-[#E8F7F0]"}`}>{fileAction === "importing" ? <ActivityIndicator color="#166443" /> : <Text className="text-success font-extrabold text-center text-xs">تطبيق القواعد المستوردة</Text>}</TouchableOpacity> : null}<View className="flex-row-reverse justify-between items-center mt-5 mb-2"><Text className="font-extrabold text-foreground">القواعد الحالية ({filteredRules.length})</Text><TouchableOpacity onPress={openNewRule}><Text className="text-primary text-xs font-extrabold">+ قاعدة جديدة</Text></TouchableOpacity></View><TextInput value={ruleQuery} onChangeText={setRuleQuery} placeholder="ابحث باسم المحفظة أو الوسم أو المرسل" placeholderTextColor="#98A2B3" className="bg-[#F7F8FA] border border-border rounded-xl px-3 py-3 text-right text-foreground mb-3" style={{ writingDirection: "rtl" }} /><Text className="text-[11px] font-bold text-muted text-right mb-2">تصفية حسب التصنيف</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} className="mb-3"><View className="flex-row-reverse gap-2">{ruleCategories.map((category) => <TouchableOpacity key={category} onPress={() => setActiveCategory(category)} className={`rounded-full px-3 py-2 ${activeCategory === category ? "bg-primary" : "bg-[#F2F4F7]"}`}><Text className={`text-xs font-bold ${activeCategory === category ? "text-white" : "text-muted"}`}>{category}</Text></TouchableOpacity>)}</View></ScrollView><Text className="text-[11px] font-bold text-muted text-right mb-2">تصفية حسب المحفظة</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} className="mb-3"><View className="flex-row-reverse gap-2"><TouchableOpacity onPress={() => setActiveWalletId("الكل")} className={`rounded-full px-3 py-2 ${activeWalletId === "الكل" ? "bg-[#1B2735]" : "bg-[#F2F4F7]"}`}><Text className={`text-xs font-bold ${activeWalletId === "الكل" ? "text-white" : "text-muted"}`}>كل المحافظ</Text></TouchableOpacity>{wallets.map((wallet) => <TouchableOpacity key={wallet.id} onPress={() => setActiveWalletId(wallet.id)} className={`rounded-full px-3 py-2 ${activeWalletId === wallet.id ? "bg-[#1B2735]" : "bg-[#F2F4F7]"}`}><Text className={`text-xs font-bold ${activeWalletId === wallet.id ? "text-white" : "text-muted"}`}>{wallet.name}</Text></TouchableOpacity>)}</View></ScrollView>{filteredRules.length ? filteredRules.map((wallet) => <TouchableOpacity key={wallet.id} onPress={() => openRule(wallet)} className={`rounded-2xl p-3 mb-2 border ${editingRuleId === wallet.id ? "bg-[#FCE8E7] border-primary" : "bg-surface border-border"}`}><View className="flex-row-reverse items-center justify-between"><Text className="font-extrabold text-foreground text-right">{wallet.name}</Text><Text className="text-[10px] bg-[#EEF2F6] text-muted px-2 py-1 rounded-full">{wallet.ruleCategory}</Text></View><Text className="text-[11px] text-muted text-right mt-1">{wallet.senderPatterns.length} مرسل · {wallet.smsKeywords.length} كلمة · {wallet.balanceAnchors.length} عبارة رصيد</Text>{wallet.ruleTags.length ? <View className="flex-row-reverse flex-wrap gap-1 mt-2">{wallet.ruleTags.map((tag) => <Text key={tag} className="text-[10px] text-primary bg-[#FCE8E7] px-2 py-1 rounded-full">#{tag}</Text>)}</View> : null}</TouchableOpacity>) : <View className="bg-[#F7F8FA] rounded-2xl p-4"><Text className="text-sm font-extrabold text-foreground text-right">لا توجد قواعد مطابقة</Text><Text className="text-xs text-muted text-right mt-1">غيّر كلمات البحث أو أزل أحد المرشحات.</Text></View>}<View className="mt-5 border-t border-border pt-4"><Text className="font-extrabold text-foreground text-right mb-3">{editingRuleId ? "تعديل القاعدة" : "إضافة قاعدة جديدة"}</Text><RuleInput label="اسم القاعدة أو المحفظة" value={ruleDraft.name} onChangeText={(value) => setRuleField("name", value)} /><RuleInput label="التصنيف" value={ruleDraft.ruleCategory} onChangeText={(value) => setRuleField("ruleCategory", value)} /><RuleInput label="العلامات (فاصلة بين القيم)" value={listText(ruleDraft.ruleTags)} onChangeText={(value) => setRuleField("ruleTags", value)} /><RuleInput label="مرسلو الرسائل (فاصلة بين القيم)" value={listText(ruleDraft.senderPatterns)} onChangeText={(value) => setRuleField("senderPatterns", value)} /><RuleInput label="كلمات تطابق المحفظة" value={listText(ruleDraft.smsKeywords)} onChangeText={(value) => setRuleField("smsKeywords", value)} /><RuleInput label="عبارات تسبق الرصيد" value={listText(ruleDraft.balanceAnchors)} onChangeText={(value) => setRuleField("balanceAnchors", value)} /><RuleInput label="عبارات تسبق مبلغ العملية" value={listText(ruleDraft.amountAnchors)} onChangeText={(value) => setRuleField("amountAnchors", value)} /><View className="bg-[#F7F8FA] border border-border rounded-2xl p-3 mb-3"><Text className="font-extrabold text-foreground text-right text-sm">اختبر القاعدة قبل الحفظ</Text><TextInput multiline value={ruleTestText} onChangeText={setRuleTestText} placeholder="الصق رسالة نصية تجريبية هنا" placeholderTextColor="#98A2B3" className="bg-white border border-border rounded-xl px-3 py-3 text-right text-foreground mt-2 min-h-20" style={{ writingDirection: "rtl", textAlignVertical: "top" }} /><TouchableOpacity onPress={testDraftRule} className="bg-[#1B2735] rounded-xl py-3 mt-2"><Text className="text-white font-extrabold text-center">تشغيل الاختبار</Text></TouchableOpacity>{ruleTestResult ? <View className="bg-white border border-border rounded-xl p-3 mt-2"><Text className="font-extrabold text-foreground text-right">نتيجة الاختبار</Text><HighlightedMessage message={ruleTestText} result={ruleTestResult} /><Text className="text-xs text-muted text-right mt-2">المزود: {ruleTestResult.provider ?? "غير مطابق"} · الرصيد: {ruleTestResult.balance ?? "غير مستخرج"}</Text><Text className="text-xs text-muted text-right mt-1">المبلغ: {ruleTestResult.amount ?? "غير مستخرج"} · الثقة: {ruleTestResult.confidence === "high" ? "مرتفعة" : ruleTestResult.confidence === "medium" ? "متوسطة" : "منخفضة"}</Text><View className="flex-row-reverse gap-3 mt-2"><Text className="text-[10px] text-success">■ رصيد مستخرج</Text><Text className="text-[10px] text-warning">■ مبلغ عملية</Text></View></View> : null}</View><TouchableOpacity onPress={saveRule} className="bg-primary rounded-xl py-3"><Text className="text-white font-extrabold text-center">حفظ القاعدة محليًا</Text></TouchableOpacity></View></ScrollView></Sheet></View></Modal>
  </ScreenContainer>;
}
function SettingsRow({ icon, title, description, control }: { icon: Parameters<typeof IconBadge>[0]["icon"]; title: string; description: string; control: React.ReactNode }) { return <View className="bg-surface border border-border rounded-3xl p-4 flex-row-reverse items-center mb-2"><IconBadge icon={icon} tone="red" /><View className="flex-1 mr-3"><Text className="font-extrabold text-foreground text-right">{title}</Text><Text className="text-[11px] leading-4 text-muted text-right mt-1">{description}</Text></View>{control}</View>; }
function SettingInput({ label, value, onChangeText, keyboardType = "default" }: { label: string; value: string; onChangeText: (value: string) => void; keyboardType?: "default" | "decimal-pad" }) { return <View className="mb-3"><Text className="text-xs font-bold text-foreground text-right mb-1.5">{label}</Text><TextInput value={value} onChangeText={onChangeText} keyboardType={keyboardType} className="bg-surface border border-border rounded-xl px-3 py-3 text-right text-foreground" style={{ writingDirection: "rtl" }} /></View>; }
function RuleInput({ label, value, onChangeText }: { label: string; value: string; onChangeText: (value: string) => void }) { return <View className="mb-3"><Text className="text-xs font-bold text-foreground text-right mb-1.5">{label}</Text><TextInput value={value} onChangeText={onChangeText} placeholder={label} placeholderTextColor="#98A2B3" className="bg-[#F7F8FA] border border-border rounded-xl px-3 py-3 text-right text-foreground" style={{ writingDirection: "rtl" }} /></View>; }
function formatBackupTime(value: string): string { const date = new Date(value); return Number.isNaN(date.getTime()) ? "تاريخ غير صالح" : new Intl.DateTimeFormat("ar-EG", { dateStyle: "medium", timeStyle: "short" }).format(date); }
function HighlightedMessage({ message, result }: { message: string; result: SmsWalletSuggestion }) {
  const parts = message.split(/([0-9٠-٩۰-۹][0-9٠-٩۰-۹,،.]*)/g);
  return <Text className="text-xs leading-6 text-right text-foreground mt-2" style={{ writingDirection: "rtl" }}>{parts.map((part, index) => {
    const numeric = Number(normalizeArabicDigits(part).replace(/[،,]/g, ""));
    const isNumber = Number.isFinite(numeric) && /[0-9٠-٩۰-۹]/.test(part);
    const isBalance = isNumber && result.balance !== undefined && Math.abs(numeric - result.balance) < 0.001;
    const isAmount = isNumber && result.amount !== undefined && Math.abs(numeric - result.amount) < 0.001;
    const className = isBalance ? "bg-[#DCFCE7] text-success font-extrabold" : isAmount ? "bg-[#FEF3C7] text-warning font-extrabold" : "text-foreground";
    return <Text key={`${part}-${index}`} className={className}>{part}</Text>;
  })}</Text>;
}
