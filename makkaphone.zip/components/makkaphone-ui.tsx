import { type ReactNode } from "react";
import { Image, Text, TouchableOpacity, View } from "react-native";
import { IconSymbol } from "@/components/ui/icon-symbol";

const logoReference = require("@/assets/images/brand/makkaphone-logo-reference.png");

export function BrandHeader({ subtitle, action, onAction }: { subtitle?: string; action?: string; onAction?: () => void }) {
  return (
    <View className="flex-row-reverse items-center justify-between mb-5" style={{ direction: "rtl" }}>
      <View className="flex-row-reverse items-center flex-1 gap-3">
        <View className="w-12 h-12 rounded-2xl bg-[#121212] overflow-hidden items-center justify-center border border-[#3B3B3B]">
          <Image source={logoReference} className="w-12 h-12" resizeMode="contain" />
        </View>
        <View className="flex-1">
          <Text className="text-xl font-extrabold text-foreground text-right" style={{ writingDirection: "rtl" }}>مكة فون</Text>
          {subtitle ? <Text className="text-xs text-muted text-right mt-0.5" style={{ writingDirection: "rtl" }}>{subtitle}</Text> : null}
        </View>
      </View>
      {action && onAction ? <TouchableOpacity onPress={onAction} className="bg-primary rounded-full px-4 py-2" activeOpacity={0.8}><Text className="text-white font-bold text-xs">{action}</Text></TouchableOpacity> : null}
    </View>
  );
}

export function SectionTitle({ title, detail, onPress }: { title: string; detail?: string; onPress?: () => void }) {
  return (
    <View className="flex-row-reverse items-center justify-between mt-2 mb-3" style={{ direction: "rtl" }}>
      <Text className="text-base font-extrabold text-foreground" style={{ writingDirection: "rtl" }}>{title}</Text>
      {detail ? <TouchableOpacity onPress={onPress} activeOpacity={0.7}><Text className="text-xs font-bold text-primary" style={{ writingDirection: "rtl" }}>{detail}</Text></TouchableOpacity> : null}
    </View>
  );
}

export function IconBadge({ icon, tone = "red" }: { icon: Parameters<typeof IconSymbol>[0]["name"]; tone?: "red" | "gold" | "green" | "ink" }) {
  const colors = { red: "bg-[#FCE8E7]", gold: "bg-[#FFF5DA]", green: "bg-[#E8F7F0]", ink: "bg-[#ECEDEE]" };
  const iconColors = { red: "#E10600", gold: "#B7791F", green: "#168B5B", ink: "#121212" };
  return <View className={`w-10 h-10 rounded-2xl items-center justify-center ${colors[tone]}`}><IconSymbol name={icon} size={21} color={iconColors[tone]} /></View>;
}

export function EmptyState({ icon, title, description, action, onAction }: { icon: Parameters<typeof IconSymbol>[0]["name"]; title: string; description: string; action?: string; onAction?: () => void }) {
  return (
    <View className="bg-surface border border-border rounded-3xl p-6 items-center mt-3">
      <View className="w-14 h-14 rounded-3xl bg-[#FCE8E7] items-center justify-center mb-3"><IconSymbol name={icon} size={29} color="#E10600" /></View>
      <Text className="text-base font-extrabold text-foreground text-center" style={{ writingDirection: "rtl" }}>{title}</Text>
      <Text className="text-sm leading-6 text-muted text-center mt-2" style={{ writingDirection: "rtl" }}>{description}</Text>
      {action && onAction ? <TouchableOpacity onPress={onAction} className="bg-primary rounded-2xl px-5 py-3 mt-5" activeOpacity={0.8}><Text className="text-white text-sm font-bold">{action}</Text></TouchableOpacity> : null}
    </View>
  );
}

export function PrimaryButton({ title, icon, onPress, disabled = false }: { title: string; icon?: Parameters<typeof IconSymbol>[0]["name"]; onPress: () => void; disabled?: boolean }) {
  return <TouchableOpacity onPress={onPress} disabled={disabled} className={`flex-row-reverse justify-center items-center rounded-2xl py-4 px-4 ${disabled ? "bg-[#F3B8B5]" : "bg-primary"}`} activeOpacity={0.8}>{icon ? <View className="ml-2"><IconSymbol name={icon} size={20} color="#FFFFFF" /></View> : null}<Text className="text-white font-extrabold" style={{ writingDirection: "rtl" }}>{title}</Text></TouchableOpacity>;
}

export function Sheet({ children }: { children: ReactNode }) {
  return <View className="bg-background rounded-t-[32px] p-5 pb-8" style={{ direction: "rtl" }}>{children}</View>;
}
