import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, type ReactNode, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { defaultAmountAnchors, defaultBalanceAnchors, walletPresets, type AppSettings, type Product, type Sale, type Wallet, type WalletOperation, type WalletOperationKind } from "@/lib/makkaphone-domain";

type MakkaphoneState = {
  hydrated: boolean;
  wallets: Wallet[];
  walletOperations: WalletOperation[];
  products: Product[];
  sales: Sale[];
  settings: AppSettings;
  addWallet: (input: Omit<Wallet, "id" | "createdAt" | "updatedAt" | "dailyUsed" | "monthlyUsed" | "updateSource">) => void;
  updateWallet: (id: string, data: Partial<Wallet>) => void;
  recordWalletOperation: (walletId: string, kind: WalletOperationKind, amount: number, note?: string, source?: "manual" | "sms") => void;
  addProduct: (input: Omit<Product, "id" | "createdAt" | "updatedAt">) => void;
  updateProduct: (id: string, data: Partial<Product>) => void;
  recordSale: (productId: string, quantity: number, unitPrice: number) => void;
  updateSettings: (data: Partial<AppSettings>) => void;
  addMissingPresetWallets: () => void;
  resetData: () => void;
};

const STORE_KEY = "makkaphone-local-state-v1";
const defaultSettings: AppSettings = {
  currency: "ج.م",
  notificationsEnabled: true,
  smsImportEnabled: false,
  minimumMargin: 12,
  shopName: "مكة فون",
  presetWalletsSeeded: false,
  lastRulesBackupAt: undefined,
  lastRulesBackupFilename: undefined,
};

const MakkaphoneContext = createContext<MakkaphoneState | null>(null);
const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

export function MakkaphoneProvider({ children }: { children: ReactNode }) {
  const [hydrated, setHydrated] = useState(false);
  const [wallets, setWallets] = useState<Wallet[]>([]);
  const [walletOperations, setWalletOperations] = useState<WalletOperation[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);

  useEffect(() => {
    AsyncStorage.getItem(STORE_KEY)
      .then((stored) => {
        if (!stored) return;
        const data = JSON.parse(stored) as Partial<MakkaphoneState>;
        const restoredSettings = { ...defaultSettings, ...(data.settings ?? {}) };
        const migratedWallets = (data.wallets ?? []).map((wallet) => ({
          ...wallet,
          accountIdentifier: wallet.accountIdentifier ?? "",
          senderPatterns: wallet.senderPatterns ?? [],
          smsKeywords: wallet.smsKeywords ?? [],
          balanceAnchors: wallet.balanceAnchors ?? defaultBalanceAnchors,
          amountAnchors: wallet.amountAnchors ?? defaultAmountAnchors,
          ruleCategory: wallet.ruleCategory ?? "غير مصنف",
          ruleTags: wallet.ruleTags ?? [],
          maximumBalance: wallet.maximumBalance ?? 0,
          singleTransactionLimit: wallet.singleTransactionLimit ?? 0,
          createdAt: wallet.createdAt ?? wallet.updatedAt ?? new Date().toISOString(),
        })) as Wallet[];
        if (!restoredSettings.presetWalletsSeeded && migratedWallets.length === 0) {
          const timestamp = new Date().toISOString();
          setWallets(walletPresets.map((preset) => ({
            id: uid(), name: preset.name, provider: preset.provider, accountIdentifier: "", senderPatterns: preset.senderPatterns, smsKeywords: preset.smsKeywords, balanceAnchors: preset.balanceAnchors, amountAnchors: preset.amountAnchors, ruleCategory: preset.ruleCategory, ruleTags: preset.ruleTags, balance: 0, maximumBalance: preset.maximumBalance, singleTransactionLimit: preset.singleTransactionLimit, warningThreshold: preset.warningThreshold, criticalThreshold: preset.criticalThreshold, dailyLimit: preset.dailyLimit, monthlyLimit: preset.monthlyLimit, dailyUsed: 0, monthlyUsed: 0, createdAt: timestamp, updatedAt: timestamp, updateSource: "manual",
          })));
          setSettings({ ...restoredSettings, presetWalletsSeeded: true });
        } else {
          setWallets(migratedWallets);
          setSettings(restoredSettings);
        }
        setWalletOperations(data.walletOperations ?? []);
        setProducts(data.products ?? []);
        setSales(data.sales ?? []);
      })
      .catch(() => undefined)
      .finally(() => setHydrated(true));
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(STORE_KEY, JSON.stringify({ wallets, walletOperations, products, sales, settings })).catch(() => undefined);
  }, [hydrated, wallets, walletOperations, products, sales, settings]);

  const addWallet = useCallback((input: Omit<Wallet, "id" | "createdAt" | "updatedAt" | "dailyUsed" | "monthlyUsed" | "updateSource">) => {
    const timestamp = new Date().toISOString();
    setWallets((current) => [{ ...input, id: uid(), dailyUsed: 0, monthlyUsed: 0, createdAt: timestamp, updatedAt: timestamp, updateSource: "manual" }, ...current]);
  }, []);

  const updateWallet = useCallback((id: string, data: Partial<Wallet>) => {
    setWallets((current) => current.map((wallet) => wallet.id === id ? { ...wallet, ...data, updatedAt: new Date().toISOString() } : wallet));
  }, []);

  const recordWalletOperation = useCallback((walletId: string, kind: WalletOperationKind, amount: number, note?: string, source: "manual" | "sms" = "manual") => {
    if (!Number.isFinite(amount) || amount <= 0) return;
    const incoming = kind === "deposit" || kind === "transfer_in";
    const outgoing = kind === "withdrawal" || kind === "transfer_out" || kind === "fee";
    setWalletOperations((current) => [{ id: uid(), walletId, kind, amount, occurredAt: new Date().toISOString(), note, source }, ...current]);
    setWallets((current) => current.map((wallet) => wallet.id === walletId ? {
      ...wallet,
      balance: incoming ? wallet.balance + amount : outgoing ? wallet.balance - amount : amount,
      dailyUsed: outgoing ? wallet.dailyUsed + amount : wallet.dailyUsed,
      monthlyUsed: outgoing ? wallet.monthlyUsed + amount : wallet.monthlyUsed,
      updatedAt: new Date().toISOString(),
      updateSource: source,
    } : wallet));
  }, []);

  const addProduct = useCallback((input: Omit<Product, "id" | "createdAt" | "updatedAt">) => {
    const timestamp = new Date().toISOString();
    setProducts((current) => [{ ...input, id: uid(), createdAt: timestamp, updatedAt: timestamp }, ...current]);
  }, []);

  const updateProduct = useCallback((id: string, data: Partial<Product>) => {
    setProducts((current) => current.map((product) => product.id === id ? { ...product, ...data, updatedAt: new Date().toISOString() } : product));
  }, []);

  const recordSale = useCallback((productId: string, quantity: number, unitPrice: number) => {
    if (!Number.isFinite(quantity) || quantity <= 0 || !Number.isFinite(unitPrice) || unitPrice < 0) return;
    setSales((current) => [{ id: uid(), productId, quantity, unitPrice, occurredAt: new Date().toISOString() }, ...current]);
    setProducts((current) => current.map((product) => product.id === productId ? { ...product, quantity: Math.max(0, product.quantity - quantity), updatedAt: new Date().toISOString() } : product));
  }, []);

  const updateSettings = useCallback((data: Partial<AppSettings>) => setSettings((current) => ({ ...current, ...data })), []);
  const addMissingPresetWallets = useCallback(() => {
    const timestamp = new Date().toISOString();
    setWallets((current) => {
      const existing = new Set(current.map((wallet) => wallet.provider.trim().toLowerCase()));
      const missing = walletPresets.filter((preset) => !existing.has(preset.provider.trim().toLowerCase()));
      if (!missing.length) return current;
      return [...current, ...missing.map((preset) => ({
        id: uid(), name: preset.name, provider: preset.provider, accountIdentifier: "", senderPatterns: preset.senderPatterns, smsKeywords: preset.smsKeywords, balanceAnchors: preset.balanceAnchors, amountAnchors: preset.amountAnchors, ruleCategory: preset.ruleCategory, ruleTags: preset.ruleTags, balance: 0, maximumBalance: preset.maximumBalance, singleTransactionLimit: preset.singleTransactionLimit, warningThreshold: preset.warningThreshold, criticalThreshold: preset.criticalThreshold, dailyLimit: preset.dailyLimit, monthlyLimit: preset.monthlyLimit, dailyUsed: 0, monthlyUsed: 0, createdAt: timestamp, updatedAt: timestamp, updateSource: "manual" as const,
      }))];
    });
    setSettings((current) => ({ ...current, presetWalletsSeeded: true }));
  }, []);
  const resetData = useCallback(() => {
    setWallets([]); setWalletOperations([]); setProducts([]); setSales([]); setSettings({ ...defaultSettings, presetWalletsSeeded: true });
  }, []);

  const value = useMemo(() => ({ hydrated, wallets, walletOperations, products, sales, settings, addWallet, updateWallet, recordWalletOperation, addProduct, updateProduct, recordSale, updateSettings, addMissingPresetWallets, resetData }), [hydrated, wallets, walletOperations, products, sales, settings, addWallet, updateWallet, recordWalletOperation, addProduct, updateProduct, recordSale, updateSettings, addMissingPresetWallets, resetData]);
  return <MakkaphoneContext.Provider value={value}>{children}</MakkaphoneContext.Provider>;
}

export function useMakkaphone() {
  const context = useContext(MakkaphoneContext);
  if (!context) throw new Error("useMakkaphone must be used inside MakkaphoneProvider");
  return context;
}
